package com.example.dokimiiii;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.FileUtils;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Formatter;

public class chatroom extends AppCompatActivity {
    public String topic;
    public String br_address;
    public InetAddress broker_address;
    public int broker_port;
    public int my_port;
    public String address;
    public String username;
    public InetAddress add;
    public int br_second_port;


    //dokimastiko gia to listview
     EditText editTxt;
     ImageButton btn;
     ListView list;
     ArrayAdapter<String> adapter;
     ArrayList<Minima> arrayList;
    MessageAdapter adapter2;
    MemberData egw;
    TextView sender_name;
    View convertView;
    Button gallery;
    Button video;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatroom);

        //WifiManager wifiManager =(WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE) ;
        //String ipAdress = Formatter;
        //textView.setText( "Your ip"+ ipAdress);

        Bundle extra1 = getIntent().getExtras();
        topic = extra1.getString("topic");
        Log.d("TOPIIIIIIIIIIIIIC",topic);

        Bundle extra3 = getIntent().getExtras();
        br_address = extra3.get("br_address").toString();
        Log.d("TOPIIIIIIIIIIIIIC",br_address);

        Bundle extra2 = getIntent().getExtras();
        broker_port = extra2.getInt("br_port");
        Log.d("TOPIIIIIIIIIIIIIC",Integer.toString(broker_port));

        Bundle extra4 = getIntent().getExtras();
        my_port = extra1.getInt("myport");
        Log.d("TOPIIIIIIIIIIIIIC",Integer.toString(my_port));

        Bundle extra5 = getIntent().getExtras();
        address = extra3.get("myaddress").toString();
        Log.d("TOPIIIIIIIIIIIIIC",address);

        try {
            add = InetAddress.getByName(address.replace("/" , ""));
            Log.d("nassos",add.toString());
            broker_address= InetAddress.getByName(br_address.replace( "/", ""));
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }


        Bundle extra6 = getIntent().getExtras();
        username = extra2.getString("username");
        Log.d("TOPIIIIIIIIIIIIIC",username);

        Bundle extra7 = getIntent().getExtras();
        br_second_port = extra2.getInt("br_second_port");



        editTxt = (EditText) findViewById(R.id.editText);
        btn = (ImageButton) findViewById(R.id.send_button);
        list = (ListView) findViewById(R.id.messages_view);

        // thimisou na to allakeis
        arrayList = new ArrayList<Minima>();

        gallery= (Button) findViewById(R.id.gallery);
        video = (Button) findViewById(R.id.video);




        //sender_name = (TextView) findViewById(R.id.name);

        /*
        LayoutInflater messageInflater = (LayoutInflater) this.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = messageInflater.inflate(R.layout.their_message, null);
        sender_name =  (TextView) convertView.findViewById(R.id.name);
        sender_name.setText("nassos");
        Log.d("NAUR",sender_name.toString());*/





        //adapter = new ArrayAdapter<String>(getApplicationContext(),R.layout.their_message,R.id.message_body , arrayList);
        adapter2 = new MessageAdapter(getApplicationContext(),arrayList,username);
        list.setAdapter(adapter2);
        //adapter2 = new ArrayAdapter<String>(getApplicationContext(),R.layout.my_message,R.id.message_body , arrayList);
         egw = new MemberData("nassos", "black");

        ActionsForBroker for_pulling= new ActionsForBroker();
        for_pulling.start();


        oldMessages old = new oldMessages();
        old.start();


        //MediaController mediaController= new MediaController(this);
    }


    private static final int UPDATE_PROGRESS = 1;
    private static final int FINAL_RESULT = 2;

    @SuppressLint("HandlerLeak")
    private final Handler myHandler = new Handler() {
        public void handleMessage(Message msg) {
            try{
                int what = msg.what;
                Object obj = msg.obj;
                if (what == UPDATE_PROGRESS){
                    sender_name.setText("nassos");
                }else if (what == FINAL_RESULT){
                    adapter2.notifyDataSetChanged();
                }

                Log.d("MY_TAG","Msg.what:"+ msg.what);

            }catch (Exception exp){
                Log.d("MY_TAG",exp.getMessage());
            }

        }
    };


    @Override
    protected void onStart() {
        super.onStart();




        //----- EDW gia eikones ---------------------
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_gall = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent_gall,3);
                adapter2.notifyDataSetChanged();
            }
        });



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String minima =  editTxt.getText().toString();
                byte[] bytes = minima.getBytes();

                arrayList.add(new Minima("text",bytes,null,username));
                editTxt.getText().clear();

                Pushing p = new Pushing( bytes, "text");
                p.start();
                adapter2.notifyDataSetChanged();
                //ActionsForBroker for_pulling= new ActionsForBroker(my_port);
                //for_pulling.start();
            }
        });

        video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("video/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Video"),4);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,@Nullable  Intent data)  {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && data != null){
            if(requestCode==3) {
                Uri selectedImage = data.getData();
                try {
                    /*Bitmap bb = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);

                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bb.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byte[] byteArray = stream.toByteArray();
                    bb.recycle();*/
                    InputStream iStream =   getContentResolver().openInputStream(selectedImage);
                    byte[] byteArray = getBytes(iStream);

                    Pushing p = new Pushing(byteArray, "image");
                    p.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }



                arrayList.add(new Minima("image", null, selectedImage,username));
                adapter2.notifyDataSetChanged();
            }

            if(requestCode==4){
                Uri selectedImageUri = data.getData();
                /*File file = new File(selectedImageUri.getPath());

                int size = (int) file.length();
                byte[] bytes2 = new byte[size];
                Log.d("filetest", getContentResolver().getType(selectedImageUri));*/
                /*
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                try {

                    FileInputStream fis = new FileInputStream(new File(selectedImageUri.getEncodedPath()));
                    byte[] buf = new byte[1024];
                    int n;
                    while (-1 != (n = fis.read(buf)))
                        baos.write(buf, 0, n);

                    byte[] videoBytes = baos.toByteArray();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }*/
                //------------------ apostolh video: not working -------------------


                /*
                InputStream iStream = null;
                try {
                    iStream = getContentResolver().openInputStream(selectedImageUri);
                    byte[] byteArray = getBytes(iStream);

                    Pushing p = new Pushing(byteArray, "video");
                    p.start();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }*/


                arrayList.add(new Minima("video", null, selectedImageUri, username));
                adapter2.notifyDataSetChanged();








            }


        }
    }




    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    int met=0;

    private class Pushing extends Thread{
        private byte[] bytes;
        private String typeofmess;

        public Pushing(byte[] bytes, String typeofmess){
            this.bytes=bytes;
            this.typeofmess=typeofmess;
        }

        public void run(){
            try {
                push();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void push() throws IOException, ClassNotFoundException {


            Log.d("YELAN","EDWWWWWWWWWWWWWWWWWW");
            Socket requestSocket = null;
            ObjectOutputStream out = null;
            ObjectInputStream in = null;
            try {
                requestSocket = new Socket(broker_address, broker_port);

                Log.d("yaaas",requestSocket.getInetAddress().toString());
                Log.d("YELAN","EDWWWWWWWWWWWWWWWWWW");
                out = new ObjectOutputStream(requestSocket.getOutputStream());
                in = new ObjectInputStream(requestSocket.getInputStream());
                out.writeInt(my_port);
                out.writeObject(add);
                out.writeUTF(topic);
                out.writeUTF(username);
                out.writeInt(1);
                //out.writeUTF(topic);
                out.flush();


                out.writeUTF(typeofmess);
                out.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }




            ArrayList<byte[]> chunksList = chunker(bytes);
            int numberOfChunks = chunksList.size();
            try {
                out.writeInt(numberOfChunks);
                out.flush();
                for (int i = 0; i < numberOfChunks; i++) { // send each chunk separately

                    out.writeObject(chunksList.get(i));
                    out.flush();
                }
                out.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }






        }

        // synartish pou dhmioyrgei ta chunks
        public ArrayList<byte[]> chunker(byte[] bytearray) {
            int blockSize = 512 * 1024;
            ArrayList<byte[]> list = new ArrayList<>();
            //ypologizoume to plithos ton blocks pou tha dimiourgisoume
            int blockCount = (bytearray.length + blockSize - 1) / blockSize;
            byte[] range = null;
            int end = -1;
            for (int i = 1; i < blockCount; i++) {
                int index = (i - 1) * blockSize;
                range = Arrays.copyOfRange(bytearray, index, index + blockSize);
                list.add(range);
            }
            //ektash
            if (bytearray.length % blockSize == 0) {
                end = bytearray.length;
            } else {
                end = bytearray.length % blockSize + blockSize * (blockCount - 1);
            }

            range = Arrays.copyOfRange(bytearray, (blockCount - 1) * blockSize, end);
            list.add(range);
            return list;
        }


    }

    // synartish pou dhmioyrgei ta chunks
    public ArrayList<byte[]> chunker(byte[] bytearray) {
        int blockSize = 512 * 1024;
        ArrayList<byte[]> list = new ArrayList<>();
        //ypologizoume to plithos ton blocks pou tha dimiourgisoume
        int blockCount = (bytearray.length + blockSize - 1) / blockSize;
        byte[] range = null;
        int end = -1;
        for (int i = 1; i < blockCount; i++) {
            int index = (i - 1) * blockSize;
            range = Arrays.copyOfRange(bytearray, index, index + blockSize);
            list.add(range);
        }
        //ektash
        if (bytearray.length % blockSize == 0) {
            end = bytearray.length;
        } else {
            end = bytearray.length % blockSize + blockSize * (blockCount - 1);
        }

        range = Arrays.copyOfRange(bytearray, (blockCount - 1) * blockSize, end);
        list.add(range);
        return list;
    }

    private class ActionsForBroker  extends Thread {
        ObjectInputStream in;
        ObjectOutputStream out;
        Socket providerSocket;
        Socket connection2;
        int port;
        int i=1;

        //TODO change path
        public String path = "C:\\Users\\user\\Desktop\\erg_katanemimena_2"+"\\" ;

        public void run() {
            //waiting for messages from broker



            while (true) {

                try {
                    providerSocket = new Socket(broker_address,br_second_port);
                    Log.d("soc","SLAY");

                    Log.d("soc","SLAY");

                    Log.d("soc","SLAY");
                    out = new ObjectOutputStream(providerSocket.getOutputStream());
                    in = new ObjectInputStream(providerSocket.getInputStream());

                    String sender = in.readUTF();
                    String typosarxeiou=in.readUTF();

                    int size = in.readInt();
                    ArrayList<byte[]> ar= new ArrayList<>();
                    for (int i=0; i<size ; i++){
                        ar.add((byte[])in.readObject());
                        //outputStream.write((byte[])in.readObject());
                    }
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                    for(byte[] a:ar){
                        outputStream.write(a);
                    }


                    //System.out.println("The message was sent by: "+sender);

                    byte[] c= outputStream.toByteArray();
                    outputStream.close();
                    //System.out.println(c.length);

                    if ( typosarxeiou.equals("image")){
                        if(!sender.equals(username)) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(c, 0, c.length);
                            Uri uri = getImageUri(getApplicationContext(), bitmap);
                            arrayList.add(new Minima("image", null, uri, sender));
                        }

                    }
                    if ( typosarxeiou.equals("video")){
                        if(!sender.equals(username)) {
                            Bitmap bitmap = BitmapFactory.decodeByteArray(c, 0, c.length);
                            Uri uri=getImageUri(getApplicationContext(),bitmap);
                            arrayList.add(new Minima("video", null, uri,sender));


                        //Log.d("soc","SLAYYYYYY");
                        }
                    }
                    if( typosarxeiou.equals("text")){
                        /*FileOutputStream out = new FileOutputStream(path +Integer.toString(port)+"\\" +Integer.toString(i) +".txt");
                        out.write(c);
                        out.close();
                        System.out.println(sender +": "+new String(c, StandardCharsets.UTF_8));
                        i=i+1;*/
                        if(!sender.equals(username)) {
                            arrayList.add(new Minima("text", c, null, sender));
                            Log.d("soc", "SLAYYYYYY");
                        }
                        //adapter2.notifyDataSetChanged();
                    }
                    if ( typosarxeiou.equals("story")){
                        FileOutputStream out = new FileOutputStream(path +"stories"+Integer.toString(port)+"\\" +sender);
                        out.write(c);
                        out.close();
                        System.out.println("story: " +sender +" was watched");
                        i=i+1;
                    }


                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }



            }



        }




        public Uri getImageUri(Context inContext, Bitmap inImage) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title"+Integer.toString(met) , null);
            met=met+1;
            return Uri.parse(path);
        }
    }


    int meta=100;
    private class oldMessages extends Thread{
        Socket pullingsocket;
        ObjectOutputStream out;
        ObjectInputStream in;
        /*public Pushing(){
            this.bytes=bytes;
            this.typeofmess=typeofmess;
        }*/

        public void run(){
            try {
                pull_all_old_messages();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        void pull_all_old_messages() throws IOException, ClassNotFoundException {
            pullingsocket = new Socket(broker_address,broker_port);
            //ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
            out = new ObjectOutputStream(pullingsocket.getOutputStream());
            in = new ObjectInputStream(pullingsocket.getInputStream());

            out.writeInt(my_port);
            out.writeObject(add);
            out.writeUTF(topic);
            out.writeUTF(username);
            out.writeInt(2);
            //out.writeUTF(topic);
            out.flush();
            String usermes;
            int size_of_mes;
            String type;
            int loop = in.readInt();
            for (int i=0; i<loop; i++){
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                type= in.readUTF();
                usermes = in.readUTF();
                size_of_mes= in.readInt();
                for (int j=0;j<size_of_mes;j++){
                    outputStream.write((byte[])in.readObject());
                }
                byte[] c= outputStream.toByteArray();
                outputStream.close();
                if(type.equals("text")){
                    //if(!usermes.equals(username)) {
                        arrayList.add(new Minima("text", c, null, usermes));
                        adapter2.notifyDataSetChanged();
                    //}
                }
                if(type.equals("image")){

                        Bitmap bitmap = BitmapFactory.decodeByteArray(c, 0, c.length);
                        Uri uri = getImageUri(getApplicationContext(), bitmap);
                        arrayList.add(new Minima("image", null, uri, usermes));
                        //adapter2.notifyDataSetChanged();
                        Message m1 = new Message();
                        m1.what = FINAL_RESULT;
                        m1.obj= 2;
                        myHandler.handleMessage(m1);

                }

            }
        }

        public Uri getImageUri(Context inContext, Bitmap inImage) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title"+Integer.toString(meta), null);
            meta=meta+1;
            return Uri.parse(path);
        }
    }






}