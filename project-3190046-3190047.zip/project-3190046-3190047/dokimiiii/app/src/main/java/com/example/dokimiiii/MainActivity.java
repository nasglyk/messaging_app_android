package com.example.dokimiiii;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private Socket socket;

    static InetAddress add;
    static InetAddress broker_ip;



    {
        try {
            //TODO Client IP
            add = InetAddress.getByName("127.0.0.1");


            //add=InetAddress.getLocalHost();
            //TODO change broker's IP, the IP of the broker you connect to for the first connection

            broker_ip= InetAddress.getByName("192.168.1.214");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
    //TODO Client's port
    public int my_port=2400;
    //TODO Change path
    public String path = "C:\\Users\\user\\Desktop\\erg_katanemimena_2" + "\\";
    //TODO Change broker's port for the first connection
    public int broker_port = 1989;




//----------------------------------
    Button btn;
    Button btn2;
    TextView status;
    EditText sleep;
    EditText tpc;
    EditText user;


    private static final int UPDATE_PROGRESS = 1;
    private static final int FINAL_RESULT = 2;

    @SuppressLint("HandlerLeak")
    private final Handler myHandler = new Handler() {
        public void handleMessage(Message msg) {
            try{
                int what = msg.what;
                Object obj = msg.obj;
                if (what == UPDATE_PROGRESS){
                    status.setText((String)obj);
                }else if (what == FINAL_RESULT){
                    status.setText((String)obj);
                }

                Log.d("MY_TAG","Msg.what:"+ msg.what);

            }catch (Exception exp){
                Log.d("MY_TAG",exp.getMessage());
            }

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = (Button) findViewById(R.id.button);
        tpc = (EditText) findViewById(R.id.topic);
        user = (EditText) findViewById(R.id.username);
        status = (TextView) findViewById(R.id.status);




    }

    @Override
    protected void onStart() {
        super.onStart();



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String topic = tpc.getText().toString();
                String username = user.getText().toString();
                MyThread2 t2 = new MyThread2(topic,username, v);
                t2.start();

            }
        });

    }

    public String answer3;
    public static Userinfo t ;
    public String res;
    public String res2;
    public int found_port;
    public int br_second_port;
    public InetAddress found_address;
    public void first_connection(String topic, String username, View v){
        //Socket requestSocket = null;

        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        try {
            // first broker that will return us all broker's info
            Log.d("MY_TAG","EDWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
            socket = new Socket(broker_ip,broker_port);
            Log.d("MY_TAG2","EDWWWWWWWWWWWWWWWWWW");
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());

            //stelnoume to user info, 0 pou shmainei first connection kai to topic
            t = new Userinfo(my_port,add,topic,username);
            //out.writeObject(t);
            out.writeInt(my_port);
            out.writeObject(add);
            out.writeUTF(topic);
            out.writeUTF(username);
            out.writeInt(0);
            out.writeUTF(topic);
            out.flush();

            // dexomaste ta stoixeia pou maw stelnei o broker sxetika me to pou tha broume to topic
            res2 = in.readUTF();
            res =in.readUTF();


            if( res.equals("vrethike") || res.equals("vrethike allou")) {
                found_port= in.readInt();
                found_address =(InetAddress) in.readObject();
                br_second_port = in.readInt();
                Intent s = new Intent(v.getContext(), chatroom.class);
                s.putExtra("topic", topic);
                s.putExtra("br_address", found_address);
                s.putExtra("br_port", found_port);
                s.putExtra("myport", my_port);
                s.putExtra("myaddress", add);
                s.putExtra("username", username);
                s.putExtra("br_second_port",br_second_port);

                startActivity(s);
            }else{

                Message m1 = new Message();
                m1.what = UPDATE_PROGRESS;
                m1.obj = res2;
                myHandler.handleMessage(m1);
            }








        } catch (UnknownHostException unknownHost) {
            System.err.println("You are trying to connect to an unknown host!");
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }catch (ClassNotFoundException e){
            //TODO auto-generated catch
            e.printStackTrace();
        }
        finally {

        }
    }

    private class MyThread2 extends Thread{
        private String topic;
        private String username;
        private View v;
        public MyThread2(String topic, String username, View v){
            this.topic=topic;
            this.username=username;
            this.v=v;
        }

        public void run(){
            first_connection(topic, username,v);

        }
    }






}