package com.example.dokimiiii;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MessageAdapter extends ArrayAdapter<Minima> {


    Context context;
    String username;


    private ArrayList<Minima> lista;


    public MessageAdapter( Context context, ArrayList<Minima> lista,String username){
        super(context, 0, lista);
        this.lista=lista;
        this.context=context;
        this.username= username;


    }






@NonNull
@Override
public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
    View listItem = convertView;
    Minima currentMovie = lista.get(position);

        if (currentMovie.getType().equals("text")) {
            if(username.equals(currentMovie.getUsername())){
                listItem = LayoutInflater.from(context).inflate(R.layout.my_message, parent, false);
            }else {
                listItem = LayoutInflater.from(context).inflate(R.layout.their_message, parent, false);
                TextView name = (TextView) listItem.findViewById(R.id.name);
                name.setText(currentMovie.getUsername());
            }
        }
        if (currentMovie.getType().equals("image")) {
            if(username.equals(currentMovie.getUsername())){
                listItem = LayoutInflater.from(context).inflate(R.layout.my_message_image, parent, false);
            }else {
                listItem = LayoutInflater.from(context).inflate(R.layout.their_message_image, parent, false);
                Log.d("eleni", "bikeeeee");
                TextView name = (TextView) listItem.findViewById(R.id.name);
                name.setText(currentMovie.getUsername());
            }
        }
        if(currentMovie.getType().equals("video")){
            listItem = LayoutInflater.from(context).inflate(R.layout.their_message_video, parent, false);
        }

// den tha einai string, tha ftiaksoume mia klasi kai tha to pairnoume apo ekei






    if (currentMovie.getType().equals("text")) {

        TextView message = (TextView) listItem.findViewById(R.id.message_body);
        message.setText(new String(currentMovie.getMnm(), StandardCharsets.UTF_8));
    }
    if (currentMovie.getType().equals("image")){
        ImageView img = (ImageView) listItem.findViewById(R.id.imageView2);

        img.setImageURI(currentMovie.getImg());
    }
    if(currentMovie.getType().equals("video")){
        VideoView video = (VideoView) listItem.findViewById(R.id.videoView);
        video.setVideoURI(currentMovie.getImg());
        video.start();
        //video.canPause();
        //video.canSeekBackward();
        //video.canSeekForward();
        //MediaController mediaController= new MediaController(context);
        //video.setMediaController(mediaController);
       //mediaController.setAnchorView(video);


    }
    return listItem;
}


}

class MessageViewHolder {
    public View avatar;
    public TextView name;
    public TextView messageBody;
}