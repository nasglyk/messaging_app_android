package com.example.dokimiiii;


import android.net.Uri;

public class Minima {
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    private String username;
    private String type;
    private byte[] mnm;

    public Uri getImg() {
        return img;
    }

    public void setImg(Uri img) {
        this.img = img;
    }

    private Uri img;

    public Minima(String type, byte[] mnm, Uri img,String username) {
        this.type=type;
        this.mnm=mnm;
        this.img=img;
        this.username=username;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte[] getMnm() {
        return mnm;
    }

    public void setMnm(byte[] mnm) {
        this.mnm = mnm;
    }
}
